export const regex: RegExp;
