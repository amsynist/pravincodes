import type { Art } from "@/lib/blog";

/**
 * Card art for the Notes index — one small animated motif per kind of note.
 *   reel  : a film strip sliding over a live waveform (video + audio models)
 *   flux  : streams of light flowing across (FLUX)
 *   type  : a dot-matrix sheet spelling "Aa" over an alpha checkerboard (image + typography)
 *   draft : ghost lines and a blinking caret (not written yet)
 * Pure SVG + CSS (blog.css → .art-*), so it costs nothing on the server and pauses for reduced motion.
 */
export default function PostArt({ art, id }: { art: Art; id: string }) {
  const g = `g-${id}`;
  if (art === "reel") return <Reel g={g} />;
  if (art === "flux") return <Flux g={g} />;
  if (art === "type") return <TypeSheet />;
  return <Draft />;
}

const VB = "0 0 320 160";

function Reel({ g }: { g: string }) {
  const frames = Array.from({ length: 9 }, (_, i) => i);
  const bars = Array.from({ length: 40 }, (_, i) => i);
  return (
    <svg className="art art-reel" viewBox={VB} preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <linearGradient id={g} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="var(--acc)" stopOpacity="0.55" />
          <stop offset="1" stopColor="var(--acc)" stopOpacity="0.05" />
        </linearGradient>
      </defs>
      <g className="art-reel__strip">
        {frames.map((i) => (
          <g key={i} transform={`translate(${i * 92 - 40} 22)`}>
            <rect width="86" height="74" rx="6" fill="rgba(255,255,255,0.035)" stroke="rgba(255,255,255,0.12)" />
            <rect x="8" y="12" width="70" height="50" rx="3" fill={`url(#${g})`} opacity={i % 2 ? 0.9 : 0.5} />
            {[0, 1, 2, 3].map((k) => (
              <g key={k}>
                <rect x={10 + k * 20} y="3" width="8" height="5" rx="1.5" fill="rgba(255,255,255,0.16)" />
                <rect x={10 + k * 20} y="66" width="8" height="5" rx="1.5" fill="rgba(255,255,255,0.16)" />
              </g>
            ))}
          </g>
        ))}
      </g>
      <g transform="translate(22 134)">
        {bars.map((i) => {
          const h = 6 + Math.abs(Math.sin(i * 0.9) * 14 + Math.sin(i * 0.37) * 8);
          return (
            <rect
              key={i}
              className="art-reel__bar"
              x={i * 7}
              y={-h / 2}
              width="3"
              height={h}
              rx="1.5"
              style={{ animationDelay: `${-(i * 0.07).toFixed(2)}s` }}
            />
          );
        })}
      </g>
    </svg>
  );
}

function Flux({ g }: { g: string }) {
  const lines = Array.from({ length: 9 }, (_, i) => i);
  const wave = (i: number) => {
    const y = 24 + i * 16;
    const a = 10 + (i % 3) * 6;
    const ph = i * 0.7;
    const pts = Array.from({ length: 17 }, (_, k) => {
      const x = -20 + k * 22.5;
      return `${x.toFixed(1)} ${(y + Math.sin(k * 0.55 + ph) * a).toFixed(1)}`;
    });
    return `M${pts[0]} L${pts.slice(1).join(" L")}`;
  };
  return (
    <svg className="art art-flux" viewBox={VB} preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <linearGradient id={g} x1="0" x2="1">
          <stop offset="0" stopColor="var(--acc)" stopOpacity="0" />
          <stop offset="0.5" stopColor="var(--acc)" stopOpacity="1" />
          <stop offset="1" stopColor="#fff" stopOpacity="0.9" />
        </linearGradient>
      </defs>
      {lines.map((i) => (
        <path key={`b${i}`} d={wave(i)} className="art-flux__base" />
      ))}
      {lines.map((i) => (
        <path
          key={i}
          d={wave(i)}
          pathLength={100}
          className="art-flux__stream"
          stroke={`url(#${g})`}
          style={{ animationDuration: `${3.2 + (i % 4) * 0.7}s`, animationDelay: `${-(i * 0.53).toFixed(2)}s` }}
        />
      ))}
    </svg>
  );
}

/* 5×7 bitmaps */
const GLYPH: Record<string, string[]> = {
  A: ["01110", "10001", "10001", "11111", "10001", "10001", "10001"],
  a: ["00000", "00000", "01110", "00001", "01111", "10001", "01111"],
};
const COLS = 26;
const ROWS = 14;
const LIT = (() => {
  const on = new Set<string>();
  const put = (ch: string, ox: number, oy: number, s: number) =>
    GLYPH[ch].forEach((row, r) =>
      [...row].forEach((b, c) => {
        if (b !== "1") return;
        for (let dy = 0; dy < s; dy++) for (let dx = 0; dx < s; dx++) on.add(`${ox + c * s + dx},${oy + r * s + dy}`);
      }),
    );
  put("A", 3, 0, 2);
  put("a", 15, 0, 2);
  return on;
})();

function TypeSheet() {
  const dots: { x: number; y: number; on: boolean; c: number }[] = [];
  for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) dots.push({ x: 27.5 + c * 10.6, y: 11 + r * 10.6, on: LIT.has(`${c},${r}`), c });
  return (
    <svg className="art art-type" viewBox={VB} preserveAspectRatio="xMidYMid slice" aria-hidden>
      <defs>
        <pattern id="alpha-cb" width="16" height="16" patternUnits="userSpaceOnUse">
          <rect width="8" height="8" fill="rgba(255,255,255,0.05)" />
          <rect x="8" y="8" width="8" height="8" fill="rgba(255,255,255,0.05)" />
        </pattern>
      </defs>
      <rect x="178" y="0" width="142" height="160" fill="url(#alpha-cb)" className="art-type__alpha" />
      {dots.map((d, i) => (
        <circle
          key={i}
          cx={d.x}
          cy={d.y}
          r={d.on ? 3.4 : 1.2}
          className={d.on ? "art-type__on" : "art-type__off"}
          style={d.on ? { animationDelay: `${(d.c * 0.06).toFixed(2)}s` } : undefined}
        />
      ))}
    </svg>
  );
}

function Draft() {
  return (
    <svg className="art art-draft" viewBox={VB} preserveAspectRatio="xMidYMid slice" aria-hidden>
      {[
        [46, 200],
        [66, 236],
        [86, 150],
      ].map(([y, w], i) => (
        <rect key={i} x="28" y={y} width={w} height="10" rx="5" className="art-draft__line" style={{ animationDelay: `${i * 0.18}s` }} />
      ))}
      <rect x="186" y="82" width="3" height="18" rx="1.5" className="art-draft__caret" />
    </svg>
  );
}
